import BuscarCep from "../components/BuscarCep";

export default function Cep(){
    return(
        <BuscarCep />
    )
}